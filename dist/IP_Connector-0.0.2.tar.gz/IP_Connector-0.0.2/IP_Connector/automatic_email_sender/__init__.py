"""
Automatic email sender using python
Manthan Chauhan
"""
__all__ = [
    'Sender'
]
